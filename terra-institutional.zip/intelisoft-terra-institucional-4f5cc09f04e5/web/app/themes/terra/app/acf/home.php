<?php
if( function_exists('acf_add_local_field_group') ):
acf_add_local_field_group(array(
	'key' => 'group_600c8d69d3188',
	'title' => 'Home',
	'fields' => array(
		array (
			'key' => 'field_8qTsH7vxqW8jgxCKm',
			'label' => 'Vitrine',
			'type' => 'tab',
		),
		array (
			'key' => 'field_md58jkdldjhsjs8dl',
			'label' => 'Exibir Sessão?',
			'name' => 'highlights_show',
			'type' => 'true_false',
			'instructions' => 'Se habilitado, exibirá o conteúdo. Caso contrário, ocultará.',
			'required' => 0,
			'default_value' => 0,
			'ui' => 1,
			'ui_on_text' => 'Sim',
			'ui_off_text' => 'Não',
		),
		array(
			'key' => 'field_uXrkhL2U3SFx7eb4',
			'label' => 'Itens',
			'name' => 'highlights_items',
			'type' => 'repeater',
			'min' => 1,
			'layout' => 'row',
			'conditional_logic' => array (
				array (
					array (
						'field' => 'field_md58jkdldjhsjs8dl',
						'operator' => '==',
						'value' => '1',
					),
				),
			),
			'sub_fields' => array (
				array(
					'key' => 'field_600c8d8ceea6f',
					'label' => 'Imagem do Banner',
					'name' => 'highlight_banner',
					'type' => 'image',
					'instructions' => 'Algo legal',
					'required' => 1,
					'return_format' => 'array',
					'preview_size' => 'medium',
				),
				array(
					'key' => 'field_MqHug527HTjWrCGC',
					'label' => 'Título',
					'name' => 'highlight_title',
					'type' => 'text',
					'required' => 1,
				),
				array(
					'key' => 'field_AzDu48a5FZDMVPrF',
					'label' => 'Subtítulo',
					'name' => 'highlight_subtitle',
					'type' => 'text',
					'required' => 1,
				),
				array(
					'key' => 'field_cx83VHsXaN6YakrC',
					'label' => 'Link do botão',
					'name' => 'highlight_link',
					'type' => 'text',
					'required' => 1,
				),
				array(
					'key' => 'field_cx83VHsXaN6Yakrd',
					'label' => 'Texto do botão',
					'name' => 'highlight_cta_text',
					'type' => 'text',
					'required' => 1,
					'default_value' => 'Entre em contato'
				),
			),
		),
		array (
            'key' => 'field_9qTsH7vxqW8jgxCKm',
            'label' => 'Benefícios',
            'type' => 'tab',
        ),
		array (
            'key' => 'field_nd58jkdldjhsjs8dl',
            'label' => 'Exibir Sessão?',
            'name' => 'benefits_show',
            'type' => 'true_false',
            'instructions' => 'Se habilitado, exibirá o conteúdo. Caso contrário, ocultará.',
            'required' => 0,
            'default_value' => 0,
            'ui' => 1,
            'ui_on_text' => 'Sim',
            'ui_off_text' => 'Não',
        ),
		array(
			'key' => 'field_zXrkhL2U3SFx7eb4',
			'label' => 'Itens',
			'name' => 'benefits_items',
			'type' => 'repeater',
			'min' => 1,
			'layout' => 'row',
			'conditional_logic' => array (
				array (
					array (
						'field' => 'field_nd58jkdldjhsjs8dl',
						'operator' => '==',
						'value' => '1',
					),
				),
			),
			'sub_fields' => array (
				array(
					'key' => 'field_z00c8d8ceea6f',
					'label' => 'Imagem',
					'name' => 'benefit_image',
					'type' => 'image',
					'required' => 1,
					'return_format' => 'array',
					'preview_size' => 'medium',
				),
				array(
					'key' => 'field_zqHug527HTjWrCGC',
					'label' => 'Título',
					'name' => 'benefit_title',
					'type' => 'text',
					'required' => 1,
				),
				array(
					'key' => 'field_zzDu48a5FZDMVPrF',
					'label' => 'Texto',
					'name' => 'benefit_summary',
					'type' => 'text',
					'required' => 1,
				),
				/*
				array(
					'key' => 'field_zx83VHsXaN6YakrC',
					'label' => 'Link "Ver mais"',
					'name' => 'benefit_link',
					'type' => 'text',
					'required' => 1,
				),
				*/
			),
		),
		array (
            'key' => 'field_9qTsH7vxqW8jgxCKb',
            'label' => 'Serviços',
            'type' => 'tab',
        ),
		array (
            'key' => 'field_nd58jkdldjhsjs8db',
            'label' => 'Exibir Sessão?',
            'name' => 'services_show',
            'type' => 'true_false',
            'instructions' => 'Se habilitado, exibirá o conteúdo. Caso contrário, ocultará.',
            'required' => 0,
            'default_value' => 0,
            'ui' => 1,
            'ui_on_text' => 'Sim',
            'ui_off_text' => 'Não',
        ),
		array(
			'key' => 'field_MqHug527HTjWrCGv',
			'label' => 'Título',
			'name' => 'services_title',
			'type' => 'text',
			'required' => 1,
			'conditional_logic' => array (
				array (
					array (
						'field' => 'field_nd58jkdldjhsjs8db',
						'operator' => '==',
						'value' => '1',
					),
				),
			),
		),
		array(
			'key' => 'field_services_items',
			'label' => 'Itens',
			'name' => 'services_items',
			'type' => 'repeater',
			'min' => 1,
			'layout' => 'row',
			'conditional_logic' => array (
				array (
					array (
						'field' => 'field_nd58jkdldjhsjs8db',
						'operator' => '==',
						'value' => '1',
					),
				),
			),
			'sub_fields' => array (
				array(
					'key' => 'field_service_title',
					'label' => 'Título',
					'name' => 'service_title',
					'type' => 'text',
					'required' => 1,
				),
				array(
					'key' => 'field_service_summary',
					'label' => 'Texto',
					'name' => 'service_summary',
					'type' => 'text',
					'required' => 1,
				),
				array(
					'key' => 'field_service_link',
					'label' => 'Link "ver mais"',
					'name' => 'service_link',
					'type' => 'text',
					'required' => 1,
					'default_value' => '/services'
				),
			),
		),
	),
	'location' => array(
		array(
			array(
				'param' => 'page_type',
				'operator' => '==',
				'value' => 'front_page',
			),
		),
	),
	'menu_order' => 0,
	'position' => 'normal',
	'style' => 'default',
	'label_placement' => 'top',
	'instruction_placement' => 'label',
	'hide_on_screen' => '',
	'active' => true,
	'description' => '',
));

endif;