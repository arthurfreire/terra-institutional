{{--
  Template Name: Page
--}}

@extends('layouts.app')

@section('content')
  <article class="article">
    <header class="article__header" style="background-image: linear-gradient(to left, transparent 20%, #002242 80%), url('{{ get_template_directory_uri() }}/assets/images/pages-bg.jpg'); background-position: left;">
      <div class="container">
        <div class="row">
          <div class="col-lg-8">
            <h1 class="article__title h1">{{ the_title() }}</h1>
          </div>
        </div>
      </div>
    </header>
    <div class="article__content">
      <div class="container">
        <div class="row">
          <div class="col-lg-8">
            {{ the_content() }}
          </div>
        </div>
      </div>
    </div>
  </article>
@endsection
