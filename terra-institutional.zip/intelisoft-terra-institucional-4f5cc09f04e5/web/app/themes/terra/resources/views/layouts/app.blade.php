<!doctype html>
<html {!! get_language_attributes() !!}>
  @include('partials.app_head')
  <body @php body_class() @endphp>
    @php do_action('get_header') @endphp
    @include('partials.app_header')
    @include('partials.app_sidebar')
    <div class="wrap" role="document">
      <div class="content">
        <main class="main">
          @yield('content')
        </main>
      </div>
    </div>
    @php do_action('get_footer') @endphp
    @include('partials.app_footer')
    @php wp_footer() @endphp

    <script src="//cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="//cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/js/all.min.js" integrity="sha512-UwcC/iaz5ziHX7V6LjSKaXgCuRRqbTp1QHpbOJ4l1nw2/boCfZ2KlFIqBUA/uRVF0onbREnY9do8rM/uT/ilqw==" crossorigin="anonymous"></script>
    <script src="//cdn.jsdelivr.net/npm/swiper@5.4.5/js/swiper.min.js"></script>
    @stack('scripts');
  </body>
</html>
