<nav id="sidebar" class="sidebar">
	<div class="sidebar__container">
		<div class="header">
			<div class="header__container">
				<div class="ml-3">
					<img src="@asset('images/logo.png')" class="logo__image" alt=""/>
				</div>
				<div class="actions flex-grow-1 justify-content-end">
					<a href="#" data-toggle="sidebar" data-target="#sidebar" class="actions__item">
						<i class="fas fa-times"></i>
					</a>
				</div>
			</div>
		</div>
		<div class="sidebar__content">
			<div class="menu">
					<a href="/" class="menu__item">Página inicial</a>
					<a href="/#vantagens" class="menu__item scroll">Vantagens</a>
					<a href="/#como-funciona" class="menu__item scroll">Como funciona?</a>
					<a href="/#planos" class="menu__item scroll">Planos</a>
					<a href="/#edicoes-anteriores" class="menu__item scroll">Edições anteriores</a>
					<a href="/#duvidas" class="menu__item scroll">Dúvidas</a>
			</div>
		</div>
	</div>
</nav>