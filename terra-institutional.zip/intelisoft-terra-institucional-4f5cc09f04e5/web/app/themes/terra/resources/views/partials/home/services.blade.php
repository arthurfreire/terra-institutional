@if(get_field('services_show'))
	<section id="services" class="services">
		<div class="container">

			<h1 class="h1 text-center">{{ get_field('services_title') }}</h1>

			<div class="services__container">
				@while(have_rows('services_items'))
						@php(the_row())
						<div class="services__item">
							<span class="number">{{ get_row_index() }}</span>
							<div class="text">
								<h2 class="h2 d-flex align-items-center">{{ get_sub_field('service_title') }}</h2>
								<p class="summary">
									{{ get_sub_field('service_summary') }}<br>
								</p>
								<a href="{{ get_sub_field('service_link') }}">ver mais</a>
							</div>
						</div>
					@endwhile
			</div>

			<div class="cta">
				<a href="#contact" class="btn btn-primary text-uppercase">
					Entre em contato
				</a>
			</div>
		</div>
	</section>
@endif
