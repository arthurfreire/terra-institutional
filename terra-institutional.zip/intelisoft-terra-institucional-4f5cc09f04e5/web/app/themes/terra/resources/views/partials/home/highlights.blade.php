@if(get_field('highlights_show'))
	<section class="highlights">
		<div id="highlights-swiper" class="swiper-container">
			<div class="swiper-wrapper">
				@while(have_rows('highlights_items'))
					@php(the_row())
					<div class="swiper-slide">
						<div class="highlights__item" style="background-image: linear-gradient(to left, transparent, black), url('{{ get_sub_field('highlight_banner')['url'] }}');">
							<div class="container">
								<div class="row justify-content-start text-left">
									<div class="col-sm-10 col-md-8 col-lg-6">
										<h3 class="h3 text-uppercase">{{ get_sub_field('highlight_subtitle') }}</h3>
										<h2 class="h1 mb-5">{!! get_sub_field('highlight_title') !!}</h2>
										<a href="{{ get_sub_field('highlight_link') }}" class="btn btn-primary text-uppercase">{{ get_sub_field('highlight_cta_text') }}</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				@endwhile
			</div>
			<div class="swiper-pagination"></div>
		</div>
	</section>

	@push('scripts')
		<script>
		$(function() {
			var highlightsSwiper = new Swiper ('#highlights-swiper', {
				loop: false,
				pagination: {
					el: '.swiper-pagination',
				},
			})
		});
		</script>
	@endpush
@endif
