<section class="contact" id="contact">
	<div class="bg-left"></div>
	<div class="container">
		<div class="row justify-content-between">
			<div class="row justify-content-center">
				<div class="col-lg-6">
					<h1 class="h1 text-center">Contato</h1>
				</div>
			</div>
			<div class="row justify-content-center">
				<div class="col-lg-6 text-center">
					<?php echo do_shortcode('[contact-form-7 title="Contato Home"]') ?>
				</div>				
			</div>
		</div>
	</div>
</section>

@push('scripts')
	<script>
		$(function() {
			var recommendationsSwiper = new Swiper ('#recommendations-swiper', {
				navigation: {
					nextEl: '.swiper-button-next',
					prevEl: '.swiper-button-prev',
				}
			})
		});
	</script>
@endpush