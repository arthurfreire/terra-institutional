<footer id="footer" class="footer">
	<div class="footer__container">
		<div class="container">
			<div class="footer__top">
				<div class="row">
					<div class="col-lg-5">
						@if(false)
							<div class="newsletter">
								<h2 class="h2">Receba todas as novidades em seu e-mail</h2>
								<form method="POST" action="#">
									<div class="input-group">
										<input type="email" class="form-control" name="email" placeholder="Seu e-mail" />
										<button type="submit" class="btn btn-secondary text-uppercase">
											Receber
										</button>
									</div>
								</form>
							</div>
						@endif
					</div>
					<div class="col-lg-4"></div>
					<div class="col-lg-3">
						<div class="social">
							<a href="#" class="social__item" target="_blank">
                				<i class="fab fa-facebook-f"></i>
							</a>
							<a href="#" class="social__item" target="_blank">
                				<i class="fab fa-instagram"></i>
							</a>
							<a href="#" class="social__item" target="_blank">
								<i class="fab fa-twitter"></i>
							</a>
							<a href="#" class="social__item" target="_blank">
								<i class="fab fa-youtube"></i>
							</a>
						</div>
					</div>
				</div>
			</div>
			<div class="footer__middle">
				<div class="logo">
					<img src="{{ 'img/logo.svg' | asset_url }}" alt="" class="logo__image"/>
				</div>
				<address class="address mb-4 mb-lg-0">
					Praça Gentil Ferreira, 1386, Alecrim, Natal/RN - CEP 59040-190<br>
					CNPJ: 02.766.637/0001-19<br>
					<a href="tel:8432130000"><i class="fas fa-phone"></i> {{ get_field('phone') }}</a><br>
          <a href="tel:849996801692"><i class="fab fa-whatsapp"></i> (84) 99680-1692</a><br>
          <a href="tel:84986282828"><i class="fab fa-whatsapp"></i> (84) 98628-2828</a><br>
					<a href="mailto:contato@sua-plataforma.com.br"><i class="far fa-envelope"></i> contato@sua-plataforma.com.br</a>
				</address>
			</div>
			<div class="footer__bottom">
				<div class="copyright">
					&copy; {{ date("Y") }} Terra&Terra. Todos os direitos reservados.
				</div>
				<div class="menu">
					<a href="/termos-de-uso" class="menu__item">
						Termos de uso
					</a>
					<a href="/politica-de-privacidade" class="menu__item">
						Política de privacidade
					</a>
				</div>
				<div class="platform">
					<a href="https://intelisoft.com.br" target="_blank">Intelisoft</a>
				</div>
			</div>
		</div>
	</div>
</footer>