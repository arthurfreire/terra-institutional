<section class="recommendations">
	<div class="bg-left"></div>
	<div class="container">
		<div class="row justify-content-between">
			<div class="col-lg-5">
				<div class="left">
					<h1 class="h1">Quem é cliente recomenda</h1>
				</div>
			</div>
			<div class="col-lg-5">
				<div id="recommendations-swiper" class="swiper-container">
					<div class="swiper-wrapper">
						<div class="swiper-slide">
							<div class="recommendations__item">
								<div class="text">
									“Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.”
								</div>
								<div class="author">
									<img class="image" src="https://widgetwhats.com/app/uploads/2019/11/free-profile-photo-whatsapp-3.png" alt=""/>
									<div class="name text-uppercase">
										Rafael<br>
										Pessoa
									</div>
								</div>
							</div>
						</div>
						<div class="swiper-slide">
							<div class="recommendations__item">
								<div class="text">
									“Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.”
								</div>
								<div class="author">
									<img class="image" src="https://widgetwhats.com/app/uploads/2019/11/free-profile-photo-whatsapp-1.png" alt=""/>
									<div class="name text-uppercase">
										Tales<br>
										Cardoso
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="swiper-button-next"></div>
					<div class="swiper-button-prev"></div>
				</div>
			</div>
		</div>
	</div>
</section>

@push('scripts')
	<script>
		$(function() {
			var recommendationsSwiper = new Swiper ('#recommendations-swiper', {
				navigation: {
					nextEl: '.swiper-button-next',
					prevEl: '.swiper-button-prev',
				}
			})
		});
	</script>
@endpush