<header id="header" class="header">
	<div class="header__container">
    <div class="logo">
      <a href="{{ home_url('/') }}"><img src="@asset('images/logo.png')" class="logo__image" alt="" /></a>
    </div>

    <div class="menu d-none d-lg-flex">
      @if(get_post()->post_name == 'home')
        {!! do_shortcode('[menu name="Home" class="home-menu"]')  !!}
      @else
        {!! do_shortcode('[menu name="Pages" class="home-menu"]')  !!}
      @endif
    </div>

    <a href="#" data-toggle="sidebar" data-target="#sidebar" class="actions__item d-flex d-lg-none">
      <i class="fas fa-bars"></i>
    </a>		
	</div>
</header>
