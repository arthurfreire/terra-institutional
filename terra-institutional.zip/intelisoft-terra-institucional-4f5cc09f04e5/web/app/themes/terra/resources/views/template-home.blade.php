{{--
  Template Name: Home
--}}

@extends('layouts.app')

@section('content')
  @include('partials.home.highlights')
  @include('partials.home.benefits')
  @include('partials.home.services')
  @include('partials.home.products')
  @if(false)
    @include('partials.home.recommendations')
    @include('partials.home.localization')
  @endif
  @include('partials.home.contact')
  @include('partials.content-page')
@endsection
