<section id="products" class="products">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-6">
				<h1 class="h1 text-center">Nossos imóveis</h1>
			</div>
		</div>
		<div class="row justify-content-center">
			@foreach($loteamentos as $l)
				<div class="col-lg-4 d-flex flex-column mb-4 type">
					<div class="products__item flex-grow-1">
						<div class="text-center">
							<h3 class="h3 text-uppercase">
								{{ get_field('location', $l->ID) }}
							</h3>
							<h2 class="h2">
								{!! get_field('title', $l->ID) !!}
							</h2>

							<div class="image">
								<img class="img-fluid" src="{{ get_field('banner', $l->ID)['url'] }}">
							</div>
						</div>

						<div class="cta">
							<a onclick="callFormToProduct('{{ get_field('title', $l->ID) }}')" href="javascript:void(0);" class="btn btn-primary d-block text-uppercase">
								Saber mais
							</a>
						</div>

						<div class="reasons">
							@foreach(get_field('benefits', $l->ID) as $benefit)
								<div class="reasons__item d-flex">
									<i class="fas fa-check icon"></i>
									<div>
										{{ $benefit['benefit'] }}
									</div>
								</div>
							@endforeach
						</div>
					</div>
				</div>
			@endforeach
		</div>
	</div>
</section>

@push('scripts')
	<script>
		function callFormToProduct(product) {
			$('input[name="your-subject"]').val("Contato - " + product);
			$('textarea[name="your-message"]').val("Olá! Gostaria de obter mais informações acerca do empreendimento " + product + ".");
			$([document.documentElement, document.body]).animate({
				scrollTop: $('#contact').offset().top
			}, 1000);
			$('input[name="your-name"]').focus();
		}
	</script>
@endpush