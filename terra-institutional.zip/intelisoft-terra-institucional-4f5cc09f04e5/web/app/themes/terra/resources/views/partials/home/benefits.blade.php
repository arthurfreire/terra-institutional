@if(get_field('benefits_show'))
	<section id="vantagens" class="benefits">
		<div class="container">
			<div id="benefits-swiper" class="swiper-container">
				<div class="swiper-wrapper">
					@while(have_rows('benefits_items'))
						@php(the_row())
						<div class="swiper-slide">
							<div class="benefits__item">
								<div class="d-flex">
									<img class="icon" src="{{ data_get(get_sub_field('benefit_image'), 'url') }}">
									<h2 class="h2">{{ get_sub_field('benefit_title') }}</h2>
								</div>
								<p class="summary">
									{!! get_sub_field('benefit_summary') !!}<br>
									@if(false)
									<a href="{{ get_sub_field('benefit_link') }}">ver mais</a>
									@endif
								</p>
							</div>
						</div>
					@endwhile
				</div>
				<div class="swiper-pagination"></div>
			</div>
		</div>
	</section>

	@push('scripts')
		<script>
			$(function() {
				var benefitsSwiper = new Swiper ('#benefits-swiper', {
					slidesPerView: 1,
					centeredSlides: true,
					pagination: {
						el: '.swiper-pagination',
					},
					breakpoints: {
						768: {
							slidesPerView: 2,
						},
						1200: {
							slidesPerView: 3,
							centeredSlides: false,
							pagination: false
						},
					}
				})
			});
		</script>
	@endpush
@endif
