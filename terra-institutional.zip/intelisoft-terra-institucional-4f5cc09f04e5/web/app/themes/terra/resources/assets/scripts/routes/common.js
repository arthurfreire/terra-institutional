export default {
  init() {
    // JavaScript to be fired on all pages
    // sidebar
    $('[data-toggle="sidebar"]').on('click', function(e) {

      e.preventDefault();

      let target = $(this).data('target');
      if(!target) {
        target = $(this).attr('href');
      }

      $(target).toggleClass('sidebar--active');
    });
  },
  finalize() {
    // JavaScript to be fired on all pages, after page specific JS is fired
  },
};
